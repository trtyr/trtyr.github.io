import time
import requests
import execjs
 
a = int(time.time()) * 1000 + 100000000
node = execjs.get()
ctx = node.compile(open('./hunxiao.js',encoding='utf-8').read())
funcName = 'm("{}")'.format(a)
pwd = ctx.eval(funcName)
m = str(pwd) + '丨' + str(int(a / 1000))
print(m)
 
sum = 0
for f in range(1,6):
    param = {'page': f,'m': m}
    headers = {'User-Agent':'yuanrenxue.project'}
    response = requests.get('https://match.yuanrenxue.com/api/match/1?page={}m={}',param,headers=headers).json()
    data = response['data']
    for i in data:
        value = i['value']
        sum += value
mid = int(sum / 50)
print(mid)